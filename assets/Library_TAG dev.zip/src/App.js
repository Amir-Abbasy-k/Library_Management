import React, {Component} from 'react';
//import logo from './logo.svg';
//import './App.css';
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";

import Home from './pages/home';
import Test from './pages/test';
import Upload_catalogu from './pages/excel_json';
import Login from './pages/login';
import Search from './pages/search';
import Patrons from './pages/patrons';
import ViewPatron from './pages/viewPatron';

class App extends Component{
  render(){
  return(

      <Router>
        {/*
        <div>
          <Link to="/">Login-</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <Link to="/test">Test</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <Link to="/Excel_json">Excel_json</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <Link to="/home">Home</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <Link to="/search">Search</Link>
        </div>
        */}


        <Switch>
          <Route exact path='/' component={Login} />
          <Route exact path='/home' component={Home} />
          <Route exact path='/test' component={Test} />
          <Route exact path='/Excel_json' component={Upload_catalogu} />
          <Route exact path='/search' component={Search} />
          <Route exact path='/patrons' component={Patrons} />
          <Route exact path='/viewPatron/:id' component={ViewPatron} />
        </Switch>
      </Router>

    )
 }
}


export default App;
