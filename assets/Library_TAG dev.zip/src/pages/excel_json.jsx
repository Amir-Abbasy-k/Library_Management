import React, {Component} from 'react';
import { BrowserRouter as Router, withRouter, Route, Link } from 'react-router-dom';
import axios from 'axios';

class Excel_json extends Component{
  constructor(props) {
    super(props)
    this.state = {
      selectedFile: null,
      fileName: '',
      catalogueTitle:'',
    };
  }

  //componentDidMount(){}

  onChangeTitle = (e) =>{
      this.setState({catalogueTitle: e.target.value})
      
  }


  onChangeHandler = event => {
    this.setState({
      selectedFile: event.target.files[0],
      fileName: event.target.files[0].name,
      loaded: 0,
    })
   
    const data = new FormData() 
    data.append('file', event.target.files[0])
    axios.post(`http://localhost:4000/upload`, data, { // receive two parameter endpoint url ,form data 
      })
      .then(res => { // then print response status
        console.log(res.statusText)
      })
  }

  onClickHandler = () => {
    const { fileName, catalogueTitle } = this.state;
       fetch(`http://localhost:4000/excel?fileName=${fileName}&catalogueTitle=${catalogueTitle}`)
      }

      
        //.then(response => response.json())
        //.then(this.getProducts)
        //.then(response => this.setState({excel: response.data}))
        //.catch(err => console.error(err))



  render(){
    const { fileName, catalogueTitle} = this.state;

      return(
        <div>
          <div>
              {/*<a href="/">Login-</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/}
              <a href="/test">Test</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="/Excel_json">Excel_json</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="/home">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="/search">Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="/patrons">Patrons</a>
            </div>
            
          <div>
            <h3>Enter Catalogue title</h3>
            <input placeholder="Enter Title" onChange={this.onChangeTitle} />
          </div>
        <input type="file" name="file" onChange={this.onChangeHandler}/><br/>
        <button onClick={this.onClickHandler}>Upload</button>
        <span>file name is = {fileName} and for {catalogueTitle} Catogary</span>
        </div>
      );
    }
}

export default withRouter(Excel_json);