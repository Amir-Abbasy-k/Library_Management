import React, {Component} from 'react';
import { BrowserRouter as Router, withRouter, Route, Link } from 'react-router-dom';
import axios from 'axios';
import  AddPatron from '../components/addPatron'
class Patrons extends Component{
  constructor(props) {
    super(props)
    this.state = {
      selectedFile: null,
      fileName: '',
      patronBatch:'',
      allPatronBatch: [],
      isLoading:  false
    };
  }

  componentDidMount(){
    this.GetPatronArrays();
  }

  GetPatronArrays = _ => {
    const {member} = this.state;
    fetch(`http://localhost:4000/GetPatronArrays`)
    .then(response => response.json())
    .then(response => this.setState({allPatronBatch: response.data[0].PatronCatogary}))
    .catch(err => console.error(err))
  }

  onChangeCatogary = (e) =>{
      this.setState({patronBatch: e.target.value})
      
  }
  onChangeTitle = (e) => {
    this.setState({patronBatch: e.target.value})
  }

  onChangeHandler = event => {
    this.setState({
      selectedFile: event.target.files[0],
      fileName: event.target.files[0].name,
      loaded: 0,
    })
   
    const data = new FormData() 
    data.append('file', event.target.files[0])
    axios.post(`http://localhost:4000/upload`, data, { // receive two parameter endpoint url ,form data 
      })
      .then(res => { // then print response status
        console.log(res.statusText)
      })
  }

  onClickHandler = () => {
    const { fileName, patronBatch, allPatronBatch, isLoading } = this.state;
    this.setState({isLoading: true});
    let batch = allPatronBatch+','+patronBatch;
       fetch(`http://localhost:4000/importPatrons?fileName=${fileName}&patronCatogary=${patronBatch}`)
       fetch(`http://localhost:4000/patronArrays?patronCatogary=${batch}`)
       .then(response => this.setState({isLoading: false}))
       .catch(err => console.error(err))

      }

      
        //.then(response => response.json())
        //.then(this.getProducts)
        //.then(response => this.setState({excel: response.data}))
        //.catch(err => console.error(err))

     renderCatogaries = (index) => <option>{index}</option>


clicKFree = () =>{
  const { fileName, patronBatch, allPatronBatch} = this.state;
  this.setState({isLoading: true});
    let batch = allPatronBatch+','+patronBatch;
       fetch(`http://localhost:4000/importPatrons`)
       .then(response => this.setState({isLoading: false}))
       .catch(err => console.error(err))
}


  render(){
    const { fileName, patronBatch, allPatronBatch} = this.state;
    let catogaries = allPatronBatch.toString().split(",");

      return(
        <div>
          <div>
              {/*<a href="/">Login-</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/}
              <a href="/test">Test</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="/Excel_json">Excel_json</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="/home">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="/search">Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="/patrons">Patrons</a>
            </div>
            
          <div>
            <h3>Enter Catalogue title</h3>
            <input placeholder="Enter Title" onChange={this.onChangeTitle} />
          </div>
        <input type="file" name="file" onChange={this.onChangeHandler}/><br/>
        <button onClick={this.onClickHandler}>Upload</button>
        <span>file name is = {fileName} and for {patronBatch}</span>
        <select onChange={this.onChangeCatogary}>  
          {catogaries.map(this.renderCatogaries)}
          </select>


<button onClick = {this.clicKFree}>Click for test</button>
      {this.state.isLoading && <h1></h1>}
        </div>
      );
    }
}

export default withRouter(Patrons);