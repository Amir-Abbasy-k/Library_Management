import React, {Component, Form} from 'react';
import { BrowserRouter as Redirect, withRouter } from "react-router-dom";
import KeyboardEventHandler from 'react-keyboard-event-handler';


class Test extends Component {  

  state = {
    code: 'barcode',
  }



    checkOut = ()=> {
        this.setState({code: 'check out by barcode'})
    }

    onKeyPressCheckOut = ()=> {
      this.setState({code: 'check out by keyPress'})
    }


  render() {

    if (this.state.toDashboard === true) {
      this.props.history.push("/");

    }

    return (
      <div>
        <h1>Register</h1>
        <button onClick={this.ShowAlertWithDelay}>Click to log in</button>
        <h1>{this.state.code}</h1>

        <KeyboardEventHandler
           handleKeys={['enter']}
           onKeyEvent={(key, e) =>  this.checkOut()} >
            <input
            ref="checkIn"
            onKeyPress={this.onKeyPressCheckOut} />
        </KeyboardEventHandler>

      </div>
    )
  }
}



export default withRouter(Test);
